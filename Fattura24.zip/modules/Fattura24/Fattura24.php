<?php
 /**************************************************************************************
 *	Fattura24 version 1.0.0-BETA, Copyright (C) 2018  Tommaso Bilotta
 *		This program is free software; you can redistribute it and/or modify
 *		it under the terms of the GNU General Public License as published by
 *		the Free Software Foundation; either version 3 of the License, or any later version.
 *
 *  Module              : Fattura24
 *  Version             : 1.0.0-BETA
 *  Vtiger              : 7.0.0, 7.0.1
 *  Author              : Tommaso Bilotta - web: www.bilotta.biz - email: tommaso@bilotta.biz
 *  Supported browsers  : Internet Explorer 7 or higher, Mozilla Firefox 3.0 or higher
 *  Licenza             : GPLv3 - https://opensource.org/licenses/GPL-3.0
 ***************************************************************************************/


require_once("modules/Fattura24/resources/installa.php");

class Fattura24 {
	var $log;
	var $db;

	function __construct() {
		$this->log = LoggerManager::getLogger('Fattura24');
		$this->db = PearDatabase::getInstance();

		// array of modules that are allowed for basic version type
		$this->basicModules = array("6", "20", "21", "22", "23");

		// array of action names used in profiles permissions
		$this->profilesActions = array("EDIT" => "EditView", // Create/Edit
			"DETAIL" => "DetailView", // View
			"DELETE" => "Delete", // Delete
		);

		$this->profilesPermissions = array();

		$this->name = "Fattura24";
		$this->id = getTabId("Fattura24");
	}


        function vtlib_handler($moduleName, $eventType) {
		if ($eventType == 'module.postinstall') {
			installa_modulo();
		}

		if ($eventType == 'module.preuninstall') {
			elimina_modulo();
		}
        }


	function getNonAdminAccessControlQuery(){
	return '';	
}


}
