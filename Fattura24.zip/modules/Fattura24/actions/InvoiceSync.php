<?php
 /**************************************************************************************
 *	Fattura24 version 1.0.0-BETA, Copyright (C) 2018  Tommaso Bilotta
 *		This program is free software; you can redistribute it and/or modify
 *		it under the terms of the GNU General Public License as published by
 *		the Free Software Foundation; either version 3 of the License, or any later version.
 *
 *  Module              : Fattura24
 *  Version             : 1.0.0-BETA
 *  Vtiger              : 7.0.0, 7.0.1
 *  Author              : Tommaso Bilotta - web: www.bilotta.biz - email: tommaso@bilotta.biz
 *  Supported browsers  : Internet Explorer 7 or higher, Mozilla Firefox 3.0 or higher
 *  Licenza             : GPLv3 - https://opensource.org/licenses/GPL-3.0
 ***************************************************************************************/

require_once("modules/Fattura24/resources/functions/fattura24.php");

class Fattura24_InvoiceSync_Action extends Vtiger_Action_Controller {
	function __construct() {
                parent::__construct();
        }

	function checkPermission() {
		return true;
	}

	public function process(Vtiger_Request $request) {
		try {
			$recordid = $request->get('recordid');
			sendInvoice($recordid);
		} catch (WebServiceException $ex) {
			echo $ex->getMessage();
		}
	}
}

