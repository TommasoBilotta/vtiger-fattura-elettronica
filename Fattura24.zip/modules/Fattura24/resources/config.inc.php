<?php
 /**************************************************************************************
 *	Fattura24 version 1.0.0-BETA, Copyright (C) 2018  Tommaso Bilotta
 *		This program is free software; you can redistribute it and/or modify
 *		it under the terms of the GNU General Public License as published by
 *		the Free Software Foundation; either version 3 of the License, or any later version.
 *
 *  Module              : Fattura24
 *  Version             : 1.0.0-BETA
 *  Vtiger              : 7.0.0, 7.0.1
 *  Author              : Tommaso Bilotta - web: www.bilotta.biz - email: tommaso@bilotta.biz
 *  Supported browsers  : Internet Explorer 7 or higher, Mozilla Firefox 3.0 or higher
 *  Licenza             : GPLv3 - https://opensource.org/licenses/GPL-3.0
 ***************************************************************************************/

$config = Array();
$config['apiKey'] = "";
$config['iban'] = "IBAN: IT....";
$config['metodopagamento'] = "Banca Popolare.....";
$config['mapping']['org']['partitaiva'] = "Partita I.V.A.";
$config['mapping']['org']['codicefiscale'] = "Codice Fiscale";
$config['mapping']['org']['provinciaconsegna'] = "Provincia consegna";
$config['mapping']['org']['provinciafatturazione'] = "Provincia fatturazione";

// true, if you want the tests and submissions to the Fattura24 API to be ignored,
// and to have a var_dump () of the variables.
$config['debug'] = false;
// false, if you want to disable the 'header("Location: ...")', of the functions
$config['debugLocation'] = true;
