<?php
 /**************************************************************************************
 *	Fattura24 version 1.0.0-BETA, Copyright (C) 2018  Tommaso Bilotta
 *		This program is free software; you can redistribute it and/or modify
 *		it under the terms of the GNU General Public License as published by
 *		the Free Software Foundation; either version 3 of the License, or any later version.
 *
 *  Module              : Fattura24
 *  Version             : 1.0.0-BETA
 *  Vtiger              : 7.0.0, 7.0.1
 *  Author              : Tommaso Bilotta - web: www.bilotta.biz - email: tommaso@bilotta.biz
 *  Supported browsers  : Internet Explorer 7 or higher, Mozilla Firefox 3.0 or higher
 *  Licenza             : GPLv3 - https://opensource.org/licenses/GPL-3.0
 ***************************************************************************************/

$config = Array();
$config['apiKey'] = "";
$config['iban'] = "IBAN: IT....";
$config['metodopagamento'] = "Banca Popolare.....";
$config['mapping']['org']['partitaiva'] = "Partita I.V.A.";
$config['mapping']['org']['codicefiscale'] = "Codice Fiscale";
$config['mapping']['org']['provinciaconsegna'] = "Provincia consegna";
$config['mapping']['org']['provinciafatturazione'] = "Provincia fatturazione";

// true, if you want invoices to be sent by email, otherwise put: false
$config['send_email'] = true;

// true, if you want the tests and submissions to the Fattura24 API to be ignored,
// and to have a var_dump () of the variables.
$config['debug'] = false;
// false, if you want to disable the 'header("Location: ...")', of the functions
$config['debugLocation'] = true;

$config['fields'] = [
	"name" => [
		"accountname",
		"firstname"
	],
	"surname" => [
		"lastname"
	],
	"street" => [
		"bill_street",
		"mailingstreet",
		"cf_751"
	],
	"ship_street" => [
		"ship_steet"
	],
	"postal_code" => [
		"bill_code",
		"mailingzip",
        "cf_757",
        "cf_797"
	],
	"ship_postal_code" => [
		"ship_code"
	],
	"city" => [
		"bill_city",
		"mailingcity",
        "cf_753",
        "cf_793"
	],
	"ship_city" => [
		"ship_city"
	],
	"state" => [
		"bill_state",
		"mailingstate",
		"cf_759"
	],
	"ship_state" => [
		"ship_state"
	],
	"country" => [
		"bill_country",
		"mailingcountry",
	],
	"ship_country" => [
		"ship_country"
	],
	"fiscal_code" => [
		"codicefiscale"
	],
	"vat_number" => [
		"partitaiva"
	],
	"phone" => [
		"phone",
		"mobile",
		"homephone",
		"otherphone"
	],
	"email" => [
		"email",
		"email1",
		"secondaryemail"
	],
	"provincia" => [
        "cf_755",
        "cf_795",
		"provincia",
		"provinciaconsegna"
	],
	"provincia_consegna" => [
		"provinciaconsegna"
	],
	"provincia_fatturazione" => [
		"provincia"
	],
	"vat_type" => [
		"vattype"
	],
	"fe_customer_pec" => [
		"fecustomerpec"
	],
	"fe_destination_code" => [
		"fedestinationcode"
	]
];