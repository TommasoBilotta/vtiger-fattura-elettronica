<?php
 /**************************************************************************************
 *	Fattura24 version 1.0.0-BETA, Copyright (C) 2018  Tommaso Bilotta
 *		This program is free software; you can redistribute it and/or modify
 *		it under the terms of the GNU General Public License as published by
 *		the Free Software Foundation; either version 3 of the License, or any later version.
 *
 *  Module              : Fattura24
 *  Version             : 1.0.0-BETA
 *  Vtiger              : 7.0.0, 7.0.1
 *  Author              : Tommaso Bilotta - web: www.bilotta.biz - email: tommaso@bilotta.biz
 *  Supported browsers  : Internet Explorer 7 or higher, Mozilla Firefox 3.0 or higher
 *  Licenza             : GPLv3 - https://opensource.org/licenses/GPL-3.0
 ***************************************************************************************/

include_once('vtlib/Vtiger/Menu.php');
include_once 'vtlib/Vtiger/Module.php';
$Vtiger_Utils_Log = true;

function add_province($_modulo) {
	$module = Vtiger_Module::getInstance($_modulo);
	$infoBlock = Vtiger_Block::getInstance('LBL_ADDRESS_INFORMATION', $module);

	$provinciafatt = Vtiger_Field::getInstance('provincia', $module);
	if ($provinciafatt)
		$provinciafatt->delete();

	$provinciafatt = new Vtiger_Field();
	$provinciafatt->name = 'provincia';
	$provinciafatt->label = 'Provincia fatturazione';
	$provinciafatt->columntype = 'VARCHAR(2)';
	$provinciafatt->uitype = 2;
	$provinciafatt->typeofdata = 'V~M';
	$infoBlock->addField($provinciafatt);


	$provinciacons = Vtiger_Field::getInstance('provinciaconsegna', $module);
	if ($provinciacons)
	        $provinciacons->delete();

	$provinciacons = new Vtiger_Field();
	$provinciacons->name = 'provinciaconsegna';
	$provinciacons->label = 'Provincia consegna';
	$provinciacons->columntype = 'VARCHAR(2)';
	$provinciacons->uitype = 2;
	$provinciacons->typeofdata = 'V~M';
	$infoBlock->addField($provinciacons);
}

function add_codice_fiscale($_modulo, $block) {
        $module = Vtiger_Module::getInstance($_modulo);
        $block = Vtiger_Block::getInstance($block, $module);

        $codicef = Vtiger_Field::getInstance('codicefiscale', $module);
        if ($codicef)
                $codicef->delete();

        $codicef  = new Vtiger_Field();
        $codicef->name = 'codicefiscale';
        $codicef->label= 'Codice Fiscale';
        $codicef->uitype= 2;
        $codicef->column = $codicef->name;
        $codicef->columntype = 'VARCHAR(255)';
        $codicef->typeofdata = 'V~M';
        $block->addField($codicef);

}

function add_partita_iva($_modulo, $block) {
	$module = Vtiger_Module::getInstance($_modulo);
	$block = Vtiger_Block::getInstance($block, $module);

	$partitaiva = Vtiger_Field::getInstance('partitaiva', $module);
	if ($partitaiva)
		$partitaiva->delete();

        $partitaiva  = new Vtiger_Field();
        $partitaiva->name = 'partitaiva';
        $partitaiva->label= 'Partita I.V.A.';
        $partitaiva->uitype= 2;
        $partitaiva->column = $partitaiva->name;
        $partitaiva->columntype = 'VARCHAR(255)';
        $partitaiva->typeofdata = 'V~M';
        $block->addField($partitaiva);
}

function installa_modulo() {
	add_province("Accounts");
	add_province("Contacts");
	add_codice_fiscale("Accounts", "LBL_ACCOUNT_INFORMATION");
	add_codice_fiscale("Contacts", "LBL_CONTACT_INFORMATION");
	add_partita_iva("Accounts", "LBL_ACCOUNT_INFORMATION");
	add_partita_iva("Contacts", "LBL_CONTACT_INFORMATION");

	$mod_invoice = Vtiger_Module::getInstance('Invoice');
	$mod_invoice->deleteLink('DETAILVIEWBASIC', 'Invia a Fattura24');
	$mod_invoice->addLink('DETAILVIEWBASIC', 'Invia a Fattura24', 'index.php?module=Fattura24&action=InvoiceSync&recordid=$RECORD$');

	$mod_acc = Vtiger_Module::getInstance('Accounts');
	$mod_acc->deleteLink('LISTVIEW', 'Sincronizza con Fattura24');
	$mod_acc->deleteLink('DETAILVIEWBASIC', 'Sincronizza con Fattura24');
	$mod_acc->addLink('LISTVIEW', 'Sincronizza con Fattura24', 'index.php?module=Fattura24&action=AccountsAllSync');
	$mod_acc->addLink('DETAILVIEWBASIC', 'Sincronizza con Fattura24', 'index.php?module=Fattura24&action=AccountSync&recordid=$RECORD$');

}

function elimina_modulo() {
	$mod_invoice = Vtiger_Module::getInstance('Invoice');
	$mod_invoice->deleteLink('DETAILVIEWBASIC', 'Invia a Fattura24');

	$mod_acc = Vtiger_Module::getInstance('Accounts');
	$mod_acc->deleteLink('LISTVIEW', 'Sincronizza con Fattura24');
	$mod_acc->deleteLink('DETAILVIEWBASIC', 'Sincronizza con Fattura24');

	$provincia = Vtiger_Field::getInstance ( 'provincia', $mod_acc );
	if ($provincia)
		$provincia->delete();

	$provinciaconsegna = Vtiger_Field::getInstance ( 'provinciaconsegna', $mod_acc );
	if ($provinciaconsegna)
		$provinciaconsegna->delete();

	$codicefiscale = Vtiger_Field::getInstance ( 'codicefiscale', $mod_acc );
	if ($codicefiscale)
		$codicefiscale->delete();

	$partita_iva = Vtiger_Field::getInstance ( 'partitaiva', $mod_acc );
	if ($partita_iva)
		$partita_iva->delete();

	$mod_con = Vtiger_Module::getInstance('Contacts');
	$provincia = Vtiger_Field::getInstance ( 'provincia', $mod_con );
	if ($provincia)
		$provincia->delete();

	$provinciaconsegna = Vtiger_Field::getInstance ( 'provinciaconsegna', $mod_con );
	if ($provinciaconsegna)
		$provinciaconsegna->delete();

	$codicefiscale = Vtiger_Field::getInstance ( 'codicefiscale', $mod_con );
	if ($codicefiscale)
		$codicefiscale->delete();

	$partita_iva = Vtiger_Field::getInstance ( 'partitaiva', $mod_con );
	if ($partita_iva)
		$partita_iva->delete();
}

