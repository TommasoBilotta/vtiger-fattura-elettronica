<?php
 /**************************************************************************************
 *	Fattura24 version 1.0.0-BETA, Copyright (C) 2018  Tommaso Bilotta
 *		This program is free software; you can redistribute it and/or modify
 *		it under the terms of the GNU General Public License as published by
 *		the Free Software Foundation; either version 3 of the License, or any later version.
 *
 *  Module              : Fattura24
 *  Version             : 1.0.0-BETA
 *  Vtiger              : 7.0.0, 7.0.1
 *  Author              : Tommaso Bilotta - web: www.bilotta.biz - email: tommaso@bilotta.biz
 *  Supported browsers  : Internet Explorer 7 or higher, Mozilla Firefox 3.0 or higher
 *  Licenza             : GPLv3 - https://opensource.org/licenses/GPL-3.0
 ***************************************************************************************/
include_once('vtlib/Vtiger/Menu.php');
include_once 'vtlib/Vtiger/Module.php';
$Vtiger_Utils_Log = true;

function add_province($_modulo) {
	$module = Vtiger_Module::getInstance($_modulo);
	$infoBlock = Vtiger_Block::getInstance('LBL_ADDRESS_INFORMATION', $module);

	$provinciafatt = Vtiger_Field::getInstance('provincia', $module);
	if ($provinciafatt)
		$provinciafatt->delete();

	$provinciafatt = new Vtiger_Field();
	$provinciafatt->name = 'provincia';
	$provinciafatt->label = 'Provincia fatturazione';
	$provinciafatt->columntype = 'VARCHAR(2)';
	$provinciafatt->uitype = 2;
	$provinciafatt->typeofdata = 'V~M';
	$infoBlock->addField($provinciafatt);


	$provinciacons = Vtiger_Field::getInstance('provinciaconsegna', $module);
	if ($provinciacons)
	        $provinciacons->delete();

	$provinciacons = new Vtiger_Field();
	$provinciacons->name = 'provinciaconsegna';
	$provinciacons->label = 'Provincia consegna';
	$provinciacons->columntype = 'VARCHAR(2)';
	$provinciacons->uitype = 2;
	$provinciacons->typeofdata = 'V~M';
	$infoBlock->addField($provinciacons);
}

function add_codice_fiscale($_modulo, $block) {
        $module = Vtiger_Module::getInstance($_modulo);
        $block = Vtiger_Block::getInstance($block, $module);

        $codicef = Vtiger_Field::getInstance('codicefiscale', $module);
        if ($codicef)
                $codicef->delete();

        $codicef  = new Vtiger_Field();
        $codicef->name = 'codicefiscale';
        $codicef->label= 'Codice Fiscale';
        $codicef->uitype= 2;
        $codicef->column = $codicef->name;
        $codicef->columntype = 'VARCHAR(255)';
        $codicef->typeofdata = 'V~M';
        $block->addField($codicef);

}

function add_partita_iva($_modulo, $block) {
	$module = Vtiger_Module::getInstance($_modulo);
	$block = Vtiger_Block::getInstance($block, $module);

	$partitaiva = Vtiger_Field::getInstance('partitaiva', $module);
	if ($partitaiva)
		$partitaiva->delete();

        $partitaiva  = new Vtiger_Field();
        $partitaiva->name = 'partitaiva';
        $partitaiva->label= 'Partita I.V.A.';
        $partitaiva->uitype= 2;
        $partitaiva->column = $partitaiva->name;
        $partitaiva->columntype = 'VARCHAR(255)';
        $partitaiva->typeofdata = 'V~M';
        $block->addField($partitaiva);
}

function add_fe_vat_nature($_modulo, $block) {
	$module = Vtiger_Module::getInstance($_modulo);
	$block = Vtiger_Block::getInstance($block, $module);

	$fieldInstance = Vtiger_Field::getInstance('fevatnature', $module);
	if ($fieldInstance)
		$fieldInstance->delete();

    $fieldInstance  = new Vtiger_Field();
    $fieldInstance->name = 'fevatnature';
    $fieldInstance->label= 'Tipo di tariffa (Natura IVA)';
    $fieldInstance->uitype= 16;
    $fieldInstance->column = $fieldInstance->name;
    $fieldInstance->columntype = 'VARCHAR(255)';
    $fieldInstance->typeofdata = 'V~M';
    $fieldInstance->setPicklistValues( Array ('N1 - escluse ex art. 15', 'N2 - non soggette', 'N3 - non imponibili', 'N4 - esenti', 'N5 - regime del margine', 'N6 - inversione contabile (reverse charge)') );
    $block->addField($fieldInstance);
}

function add_fe_payment_code($_modulo, $block) {
	$module = Vtiger_Module::getInstance($_modulo);
	$block = Vtiger_Block::getInstance($block, $module);

	$fieldInstance = Vtiger_Field::getInstance('fepaymentcode', $module);
	if ($fieldInstance)
		$fieldInstance->delete();

    $fieldInstance  = new Vtiger_Field();
    $fieldInstance->name = 'fepaymentcode';
    $fieldInstance->label= 'Code di payment';
    $fieldInstance->uitype= 16;
    $fieldInstance->column = $fieldInstance->name;
    $fieldInstance->columntype = 'VARCHAR(255)';
    $fieldInstance->typeofdata = 'V~M';
    $fieldInstance->setPicklistValues( Array ('MP01 - per i pagamenti in contanti', 'MP05 - per i pagamenti tramite bonifico', 'MP08 - per i pagamenti tramite carta di credito', 'MP12 - per i pagamenti tramite Riba') );
    $block->addField($fieldInstance);
}

function add_vat_type($_modulo, $block) {
	$module = Vtiger_Module::getInstance($_modulo);
	$block = Vtiger_Block::getInstance($block, $module);

	$fieldInstance = Vtiger_Field::getInstance('vattype', $module);
	if ($fieldInstance)
		$fieldInstance->delete();

    $fieldInstance  = new Vtiger_Field();
    $fieldInstance->name = 'vattype';
    $fieldInstance->label= 'Tipo di IVA';
    $fieldInstance->uitype= 16;
    $fieldInstance->column = $fieldInstance->name;
    $fieldInstance->columntype = 'VARCHAR(255)';
    $fieldInstance->typeofdata = 'V~O';
    $fieldInstance->setPicklistValues( Array ('I - Immediata', 'S - Pagamenti separati') );
    $block->addField($fieldInstance);
}

function add_fe_customer_pec($_modulo, $block) {
	$module = Vtiger_Module::getInstance($_modulo);
	$block = Vtiger_Block::getInstance($block, $module);

	$fieldInstance = Vtiger_Field::getInstance('fecustomerpec', $module);
	if ($fieldInstance)
		$fieldInstance->delete();

        $fieldInstance  = new Vtiger_Field();
        $fieldInstance->name = 'fecustomerpec';
        $fieldInstance->label= 'Posta Elettronica Certificata (PEC)';
        $fieldInstance->uitype= 2;
        $fieldInstance->column = $fieldInstance->name;
        $fieldInstance->columntype = 'VARCHAR(255)';
        $fieldInstance->typeofdata = 'V~M';
        $block->addField($fieldInstance);
}

function add_fe_destination_code($_modulo, $block) {
	$module = Vtiger_Module::getInstance($_modulo);
	$block = Vtiger_Block::getInstance($block, $module);

	$fieldInstance = Vtiger_Field::getInstance('fedestinationcode', $module);
	if ($fieldInstance)
		$fieldInstance->delete();

        $fieldInstance  = new Vtiger_Field();
        $fieldInstance->name = 'fedestinationcode';
        $fieldInstance->label= 'Codice di destinazione';
        $fieldInstance->uitype= 2;
        $fieldInstance->column = $fieldInstance->name;
        $fieldInstance->columntype = 'VARCHAR(255)';
        $fieldInstance->typeofdata = 'V~M';
        $block->addField($fieldInstance);
}

function installa_modulo() {
	add_province("Accounts");
	add_province("Contacts");
	add_codice_fiscale("Accounts", "LBL_ACCOUNT_INFORMATION");
	add_codice_fiscale("Contacts", "LBL_CONTACT_INFORMATION");
	add_partita_iva("Accounts", "LBL_ACCOUNT_INFORMATION");
	add_partita_iva("Contacts", "LBL_CONTACT_INFORMATION");
    add_fe_vat_nature("Products", "LBL_PRICING_INFORMATION");
    add_fe_payment_code("Invoice", "LBL_INVOICE_INFORMATION");
    add_vat_type("Accounts", "LBL_ACCOUNT_INFORMATION");
    add_vat_type("Contacts", "LBL_CONTACT_INFORMATION");
    add_fe_customer_pec("Accounts", "LBL_ADDRESS_INFORMATION");
    add_fe_customer_pec("Contacts", "LBL_ADDRESS_INFORMATION");
    add_fe_destination_code("Accounts", "LBL_ADDRESS_INFORMATION");
    add_fe_destination_code("Contacts", "LBL_ADDRESS_INFORMATION");

	$mod_invoice = Vtiger_Module::getInstance('Invoice');
	$mod_invoice->deleteLink('DETAILVIEWBASIC', 'Invia a Fattura24');
	$mod_invoice->addLink('DETAILVIEWBASIC', 'Invia a Fattura24', 'index.php?module=Fattura24&action=InvoiceSync&recordid=$RECORD$');
    $mod_invoice->deleteLink('DETAILVIEWBASIC', 'Invia a Fattura elettronica a Fattura24');
	$mod_invoice->addLink('DETAILVIEWBASIC', 'Invia a Fattura elettronica a Fattura24', 'index.php?module=Fattura24&action=FatturaElettronicaSync&recordid=$RECORD$');

    $modules = array("Accounts", "Contacts");
    foreach ($modules as $mod) {
        $v_mod = Vtiger_Module::getInstance($mod);
        $v_mod->deleteLink('LISTVIEW', 'Sincronizza con Fattura24');
        $v_mod->addLink('LISTVIEW', 'Sincronizza con Fattura24', 'index.php?module=Fattura24&action=AllCustomersSync&srcmodule=$MODULE$&app=INVENTORY');
        $v_mod->deleteLink('DETAILVIEWBASIC', 'Sincronizza con Fattura24');
        $v_mod->addLink('DETAILVIEWBASIC', 'Sincronizza con Fattura24', 'index.php?module=Fattura24&action=CustomerSync&recordid=$RECORD$&srcmodule=$MODULE$&app=INVENTORY');
    }

}

function elimina_modulo() {
	$mod_invoice = Vtiger_Module::getInstance('Invoice');
	$mod_invoice->deleteLink('DETAILVIEWBASIC', 'Invia a Fattura24');
    $mod_invoice->deleteLink('DETAILVIEWBASIC', 'Invia a Fattura elettronica a Fattura24');

    $modules = array("Accounts", "Contacts");
    foreach ($modules as $mod) {
        $v_mod = Vtiger_Module::getInstance($mod);
        $v_mod->deleteLink('LISTVIEW', 'Sincronizza con Fattura24');
        $v_mod->deleteLink('DETAILVIEWBASIC', 'Sincronizza con Fattura24');
    }

	$provincia = Vtiger_Field::getInstance ( 'provincia', $mod_acc );
	if ($provincia)
		$provincia->delete();

	$provinciaconsegna = Vtiger_Field::getInstance ( 'provinciaconsegna', $mod_acc );
	if ($provinciaconsegna)
		$provinciaconsegna->delete();

	$codicefiscale = Vtiger_Field::getInstance ( 'codicefiscale', $mod_acc );
	if ($codicefiscale)
		$codicefiscale->delete();

	$partita_iva = Vtiger_Field::getInstance ( 'partitaiva', $mod_acc );
	if ($partita_iva)
		$partita_iva->delete();

    $vat_type = Vtiger_Field::getInstance ( 'vattype', $mod_acc );
	if ($vat_type)
		$vat_type->delete();

    $fe_customer_pec = Vtiger_Field::getInstance ( 'fecustomerpec', $mod_acc );
	if ($fe_customer_pec)
		$fe_customer_pec->delete();

    $fe_destination_code = Vtiger_Field::getInstance ( 'fedestinationcode', $mod_acc );
	if ($fe_destination_code)
		$fe_destination_code->delete();

	$mod_con = Vtiger_Module::getInstance('Contacts');
	$provincia = Vtiger_Field::getInstance ( 'provincia', $mod_con );
	if ($provincia)
		$provincia->delete();

	$provinciaconsegna = Vtiger_Field::getInstance ( 'provinciaconsegna', $mod_con );
	if ($provinciaconsegna)
		$provinciaconsegna->delete();

	$codicefiscale = Vtiger_Field::getInstance ( 'codicefiscale', $mod_con );
	if ($codicefiscale)
		$codicefiscale->delete();

	$partita_iva = Vtiger_Field::getInstance ( 'partitaiva', $mod_con );
	if ($partita_iva)
		$partita_iva->delete();

    $vat_type = Vtiger_Field::getInstance ( 'vattype', $mod_con );
	if ($vat_type)
		$vat_type->delete();

    $fe_customer_pec = Vtiger_Field::getInstance ( 'fecustomerpec', $mod_con );
	if ($fe_customer_pec)
		$fe_customer_pec->delete();

    $fe_destination_code = Vtiger_Field::getInstance ( 'fedestinationcode', $mod_con );
	if ($fe_destination_code)
		$fe_destination_code->delete();

    $mod_prod = Vtiger_Module::getInstance('Products');
	$fevatnature = Vtiger_Field::getInstance ( 'fevatnature', $mod_prod );
	if ($fevatnature)
		$fevatnature->delete();

    $fepaymentcode = Vtiger_Field::getInstance ( 'fepaymentcode', $mod_prod );
	if ($fepaymentcode)
		$fepaymentcode->delete();
}

function update_modulo() {
    add_fe_vat_nature("Products", "LBL_PRICING_INFORMATION");
    add_fe_payment_code("Invoice", "LBL_INVOICE_INFORMATION");
    add_vat_type("Accounts", "LBL_ACCOUNT_INFORMATION");
    add_vat_type("Contacts", "LBL_CONTACT_INFORMATION");
    add_fe_customer_pec("Accounts", "LBL_ADDRESS_INFORMATION");
    add_fe_customer_pec("Contacts", "LBL_ADDRESS_INFORMATION");
    add_fe_destination_code("Accounts", "LBL_ADDRESS_INFORMATION");
    add_fe_destination_code("Contacts", "LBL_ADDRESS_INFORMATION");

    $mod_invoice = Vtiger_Module::getInstance('Invoice');
	$mod_invoice->deleteLink('DETAILVIEWBASIC', 'Invia a Fattura24');
	$mod_invoice->addLink('DETAILVIEWBASIC', 'Invia a Fattura24', 'index.php?module=Fattura24&action=InvoiceSync&recordid=$RECORD$');
    $mod_invoice->deleteLink('DETAILVIEWBASIC', 'Invia a Fattura elettronica a Fattura24');
	$mod_invoice->addLink('DETAILVIEWBASIC', 'Invia a Fattura elettronica a Fattura24', 'index.php?module=Fattura24&action=FatturaElettronicaSync&recordid=$RECORD$');

    $modules = array("Accounts", "Contacts");
    foreach ($modules as $mod) {
        $v_mod = Vtiger_Module::getInstance($mod);
        $v_mod->deleteLink('LISTVIEW', 'Sincronizza con Fattura24');
        $v_mod->addLink('LISTVIEW', 'Sincronizza con Fattura24', 'index.php?module=Fattura24&action=AllCustomersSync&srcmodule=$MODULE$&app=INVENTORY');
        $v_mod->deleteLink('DETAILVIEWBASIC', 'Sincronizza con Fattura24');
        $v_mod->addLink('DETAILVIEWBASIC', 'Sincronizza con Fattura24', 'index.php?module=Fattura24&action=CustomerSync&recordid=$RECORD$&srcmodule=$MODULE$&app=INVENTORY');
    }
}
