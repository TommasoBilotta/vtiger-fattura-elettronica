<?php
 /**************************************************************************************
 *	Fattura24 version 1.0.0-BETA, Copyright (C) 2018  Tommaso Bilotta
 *		This program is free software; you can redistribute it and/or modify
 *		it under the terms of the GNU General Public License as published by
 *		the Free Software Foundation; either version 3 of the License, or any later version.
 *
 *  Module              : Fattura24
 *  Version             : 1.0.0-BETA
 *  Vtiger              : 7.0.0, 7.0.1
 *  Author              : Tommaso Bilotta - web: www.bilotta.biz - email: tommaso@bilotta.biz
 *  Supported browsers  : Internet Explorer 7 or higher, Mozilla Firefox 3.0 or higher
 *  Licenza             : GPLv3 - https://opensource.org/licenses/GPL-3.0
 ***************************************************************************************/

function getConfig() {
	include "modules/Fattura24/resources/config.inc.php";
	return $config;
}

function retriveEntity($id, $module) {
	try {
		$focus = CRMEntity::getInstance($module);
		$focus->id = $id;
		$focus->apply_field_security();
		$focus->retrieve_entity_info($id,$module);
		return $focus;
	} catch(Exception $e) {
		echo $e->getMessage();
		return "";
	}
}

function testApiKey() {
	try {
		$config = getConfig();
		$apiKey = $config['apiKey'];

		echo "Verifico le apiKey($apiKey)....</BR>";
		$post = [ "apiKey" => $apiKey ];

		$ret = postHttp("https://www.app.fattura24.com/api/v0.3/TestKey", $post);
		echo "Risultato: ".$ret."</BR>";

		$dom = new DOMDocument;
		$dom->loadXML( html_entity_decode($ret) );
		$returnCode = $dom->getElementsByTagName('returnCode')->item(0)->nodeValue;

		if ($returnCode == 1)
			return true;
		else
			return false;


	} catch(Exception $e) {
		echo $e->getMessage();
	}
}

function scaricaDocumento($docid) {
	try {
                $config = getConfig();
                $apiKey = $config['apiKey'];

		$post = [
				"apiKey" => $apiKey,
				"docId" => $docid
		];

		$ret = postHttp("https://www.app.fattura24.com/api/v0.3/GetFile", $post);

		return $ret;
	} catch(Exception $e) {
		echo $e->getMessage();
	}
}

function dumpEntity($entity) {
	try {
		foreach ($entity->column_fields as $fieldname => $value)
			echo "$fieldname => $value</BR>";
	} catch(Exception $e) {
		echo $e->getMessage();
	}
}

function retriveInvoice($id) {
	try {
		$invoice = retriveEntity($id, "Invoice");
		$accountid=$invoice->column_fields["account_id"];
		$account = retriveEntity($accountid, "Accounts");
		$contactid=$invoice->column_fields["contact_id"];
		$contact = retriveEntity($contactid, "Contacts");
		$related_products = getAssociatedProducts("Invoice",$invoice);

		$ret = [
			"invoice" => $invoice,
			"account" => $account,
			"contact" => $contact,
			"products" => $related_products
		];

		return $ret;
	} catch (WebServiceException $ex) {
		echo $ex->getMessage();
	}
}

function get_columnname($label) {
	try {
		$adb = PearDatabase::getInstance();
		$query = "select columnname from vtiger_field where fieldlabel = \"".$label."\" and tablename like \"vtiger_account%\"";
		$ids = $adb->pquery($query);
		if ($adb->num_rows($ids) > 0) {
			$data = $adb->fetch_array($ids);
			return $data['columnname'];
		} else
			return null;
	} catch(Exception $e) {
		echo $ex->getMessage();
	}
}

function saveAllCustomers($module, $app) {
	try {
        $config = getConfig();
        $debugLocation = $config['debugLocation'];

		$adb = PearDatabase::getInstance();
        if ($module == "Accounts") {
            $ids = $adb->pquery("select a.accountid as id from vtiger_account a, vtiger_crmentity b where a.accountid = b.crmid and b.deleted = 0");
        } elseif ($module == "Contacts") {
            $ids = $adb->pquery("select a.contactid as id from vtiger_contactdetails a, vtiger_crmentity b where a.contactid = b.crmid and b.deleted = 0");
        } else {
            echo "Errore, modulo sconosciuto.";
            return;
        }
		if ($adb->num_rows($ids) > 0) {
			while ($data = $adb->fetch_array($ids))
				saveCustomer($data['id'], $module, $app);
		}

        if ($debugLocation) {
            header("Location: index.php?module=".$module."&view=List&app=".$app."");
        }
	} catch (Exception $ex) {
		echo $ex->getMessage();
	}
}

function saveCustomer($id, $module, $app, $redirect = false) {
	try {
        $config = getConfig();
        $debug = $config['debug'];
        $debugLocation = $config['debugLocation'];

        if (!$debug) {
            $apiKey = $config['apiKey'];

    		if (!testApiKey()) {
    			echo "C'è un problema di nella apiKey..... Questo bisogna impostarlo bene congli alert....";
    			return;
    		}
        }

		$account = retriveEntity($id, $module);
		$xml = serializzaCustomer($account);
		file_put_contents("CONTATTO", $xml);
        if (!$debug) {
    		$post = [
    				"apiKey" => $apiKey,
    				"xml"	=> $xml
    		];
    		$ret = postHttp("https://www.app.fattura24.com/api/v0.3/SaveCustomer", $post);
    		echo $ret;
            $dom = new DOMDocument;
            $dom->loadXML(html_entity_decode($ret) );
        } else {
            var_dump($xml);
            if ($module == "Contacts"){
                $id_name = preg_replace("/[^0-9]/", '', $account->column_fields["contact_no"]);
            } else if ($module == "Accounts") {
                $id_name = preg_replace("/[^0-9]/", '', $account->column_fields["account_no"]);
            } else {
                $id_name = $account->id;
            }
            $fileName = 'Customer_' . sprintf('%06d', $id_name) . '_' . $module . '.xml';
            $document = save_file($xml, strlen($xml), $fileName);

            $account->save_related_module($module,$account->id,"Documents",$document->id);

            if ($debugLocation) {
                if ($redirect) {
                    header("Location: index.php?module=".$module."&relatedModule=Documents&view=Detail&record=".$id."&mode=showRelatedList&relationId=78&tab_label=Documents&app=".$app."");
                    return ;
                }
            }
        }

        if ($debugLocation) {
    		if ($redirect) {
    			header("Location: index.php?module=".$module."&view=Detail&record=".$id."&app=".$app."");
            }
        }

	} catch(Exception $e) {
		echo $e->getMessage();
	}
}

function saveDocument($id, $type) {
	try {
        $config = getConfig();
        $debug = $config['debug'];
        $debugLocation = $config['debugLocation'];

        if (!$debug) {
            $apiKey = $config['apiKey'];

            if (!testApiKey()) {
                echo "C'è un problema di nella apiKey..... Questo bisogna impostarlo bene congli alert....";
                return;
            }
        }

		$invoice = retriveInvoice($id);
        $xml = serializzaDocumento($invoice, $type);
		file_put_contents("FATTURA", $xml);
        if (!$debug) {
    		$post = [
    			"apiKey" => $apiKey,
    			"xml"   => $xml
                    ];
            $ret = postHttp("https://www.app.fattura24.com/api/v0.3/SaveDocument", $post);

            $dom = new DOMDocument;
            $dom->loadXML( html_entity_decode($ret) );
            $returnCode = $dom->getElementsByTagName('returnCode')->item(0)->nodeValue;
            $docid = $dom->getElementsByTagName('docId')->item(0)->nodeValue;
            $pdf = scaricaDocumento($docid);
            $invoice_number = preg_replace("/[^0-9]/", '', $invoice["invoice"]->column_fields["invoice_no"]);
            $fileName = 'Invoice_' . sprintf('%06d', $invoice_number) . '_' . $type . '.pdf';
            $document = save_file($pdf, strlen($pdf), $fileName);

            $invoice['invoice']->save_related_module("Invoice",$invoice['invoice']->id,"Documents",$document->id);
        } else {
            var_dump($xml);
            $invoice_number = preg_replace("/[^0-9]/", '', $invoice["invoice"]->column_fields["invoice_no"]);
            $fileName = 'Invoice_' . sprintf('%06d', $invoice_number) . '_' . $type . '.xml';
            $document = save_file($xml, strlen($xml), $fileName);

            $invoice['invoice']->save_related_module("Invoice",$invoice['invoice']->id,"Documents",$document->id);
        }

        if ($debugLocation) {
            header("Location: index.php?module=Invoice&relatedModule=Documents&view=Detail&record=".$invoice['invoice']->id."&mode=showRelatedList&relationId=78&tab_label=Documents&app=".$app."");
        }

	} catch(Exception $e) {
		echo $e->getMessage();
	}
}

function postHttp($url, $post, $headers = null) {
	try {
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post) );
		if ($headers != null)
			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$response = curl_exec($ch);

		if (curl_error($ch)) {
			trigger_error('Curl Error:' . curl_error($ch));
		}

		curl_close($ch);

		return $response;
	} catch(Exception $e) {

	}
}

function get_field_data($data, $name) {
	$config = getConfig();
	foreach ($config["fields"][$name] as $field) {
		try {
			$value = htmlspecialchars($data[$field]);
			if ($value) {
				return $value;
			}
		} catch(Exception $e) {
			echo $e;
		}
	}

	return "";
}

function serializzaCustomer($entity) {
	$ret="";
	$entity_fields = $entity->column_fields;
	
	$name = get_field_data($entity_fields, "name");
	$surname = get_field_data($entity_fields, "surname");
	$phone = get_field_data($entity_fields, "phone");
	$vat_number = get_field_data($entity_fields, "vat_number");
	$fiscal_code = get_field_data($entity_fields, "fiscal_code");

	$vat_type = get_field_data($entity_fields, "vat_type");
	$fe_customer_pec = get_field_data($entity_fields, "fe_customer_pec");
	$fe_destination_code = get_field_data($entity_fields, "fe_destination_code");

	$email = get_field_data($entity_fields, "email");
	$street = get_field_data($entity_fields, "street");
	$city = get_field_data($entity_fields, "city");
	$state = get_field_data($entity_fields, "state");
	$postal_code = get_field_data($entity_fields, "postal_code");
	$country = get_field_data($entity_fields, "country");
	$provincia = get_field_data($entity_fields, "provincia");

	$country = $country ?: $state;
	
	if ($vat_type) {
		$vat_type = explode(" -", $vat_type)[0];
	}

	$ret =		"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n".
			"<Fattura24>\n".
			"	<Document>\n".
			"		<CustomerName>".($surname ? ($name." ".$surname) : $name)."</CustomerName>\n".
			"		<CustomerAddress>$street</CustomerAddress>\n".
			"		<CustomerPostcode>$postal_code</CustomerPostcode>\n".
			"		<CustomerCity>$city</CustomerCity>\n".
			"		<CustomerProvince>$provincia</CustomerProvince>\n".
			"		<CustomerCountry>$country</CustomerCountry>\n".
			"		<CustomerFiscalCode>$fiscal_code</CustomerFiscalCode>\n".
			"		<CustomerVatCode>$vat_number</CustomerVatCode>\n".
			"		<CustomerCellPhone>$phone</CustomerCellPhone>\n".
			"		<CustomerEmail>$email</CustomerEmail>\n".
            "		<VatType>".$vat_type."</VatType>\n".
            "		<FeCustomerPec>".$fe_customer_pec."</FeCustomerPec>\n".
            "		<FeDestinationCode>".$fe_destination_code."</FeDestinationCode>\n".
			"	</Document>\n".
			"</Fattura24>\n";

	return $ret;
}

function serializzaDocumento($fattura, $type) {
	$config = getConfig();

    $campo_partitaiva = get_columnname( $config['mapping']['org']['partitaiva']);
    $campo_codicefiscale = get_columnname( $config['mapping']['org']['codicefiscale']);
    $campo_provinciafatturazione = get_columnname( $config['mapping']['org']['provinciafatturazione'] );
	$campo_provinciaconsegna = get_columnname( $config['mapping']['org']['provinciaconsegna'] );
	$metodopagamento = $config['metodopagamento'];
	$iban = $config['iban'];
	$send_email = $config['send_email'];

	$invoice_vet = $fattura["invoice"]->column_fields;
	$account_vet = $fattura["account"];
	$contact_vet = $fattura["contact"];

# Invoice
	$subject = htmlspecialchars($invoice_vet["subject"]);
    $sub_totale = htmlspecialchars($invoice_vet["hdnSubTotal"]);
	$totale = htmlspecialchars($invoice_vet["hdnGrandTotal"]);
	$iva_amount = htmlspecialchars($invoice_vet["tax1"]);
    if (!$iva_amount) {
        $iva_amount = htmlspecialchars($invoice_vet["tax8"]);
    }
	$tasse = $sub_totale * ($iva_amount / 100);
	$termini = htmlspecialchars($invoice_vet["terms_conditions"]);
	$data_pagamento = $invoice_vet['duedate'];

    if ($type == "FE") {
        $fepaymentcode = explode(" -", $invoice_vet["fepaymentcode"])[0];
    }

# Customer
	if ($account_vet) {
		$entity_fields = $account_vet->column_fields;
	
		// $nome = htmlspecialchars($account_vet["accountname"]);
		// $phone = htmlspecialchars($account_vet["phone"]);
		// $piva = htmlspecialchars($account_vet["partitaiva"]);
		// $codicefiscale = htmlspecialchars($account_vet["codicefiscale"]);
		// $provinciafatturazione = htmlspecialchars($account_vet["provincia"]);
		// $provinciaconsegna = htmlspecialchars($account_vet["provinciaconsegna"]);

		// if ($type == "FE") {
		// 	$vattype = $account_vet["vattype"];
		// 	$fecustomerpec = htmlspecialchars($account_vet["fecustomerpec"]);
		// 	$fedestinationcode = htmlspecialchars($account_vet["fedestinationcode"]);
		// }

		// $email = htmlspecialchars($account_vet["email1"]);
		// $bill_street = htmlspecialchars($account_vet["bill_street"]);
		// $bill_city = htmlspecialchars($account_vet["bill_city"]);
		// $bill_state = htmlspecialchars($account_vet["bill_state"]);
		// $bill_code = htmlspecialchars($account_vet["bill_code"]);
		// $bill_country = htmlspecialchars($account_vet["bill_country"]);
		// $bill_pobox = htmlspecialchars($account_vet["bill_pobox"]);
		// 	$ship_street = htmlspecialchars($account_vet["ship_street"]);
		// 	$ship_city = htmlspecialchars($account_vet["ship_city"]);
		// 	$ship_state = htmlspecialchars($account_vet["ship_state"]);
		// 	$ship_code = htmlspecialchars($account_vet["ship_code"]);
		// 	$ship_country = htmlspecialchars($account_vet["ship_country"]);
		// 	$ship_pobox = htmlspecialchars($account_vet["ship_pobox"]);


		// if (!$bill_country) {
		// 	$bill_country = $bill_state;
		// }
	} else {
		$entity_fields = $contact_vet->column_fields;
	}

	$name = get_field_data($entity_fields, "name");
	$surname = get_field_data($entity_fields, "surname");
	$phone = get_field_data($entity_fields, "phone");
	$vat_number = get_field_data($entity_fields, "vat_number");
	$fiscal_code = get_field_data($entity_fields, "fiscal_code");
	$provincia_fatturazione = get_field_data($entity_fields, "provincia_fatturazione");
	$provincia_consegna = get_field_data($entity_fields, "provincia_consegna");

	if ($type == "FE") {
		$vat_type = get_field_data($entity_fields, "vat_type");
		$fe_customer_pec = get_field_data($entity_fields, "fe_customer_pec");
		$fe_destination_code = get_field_data($entity_fields, "fe_destination_code");
	}

	$email = get_field_data($entity_fields, "email");
	$street = get_field_data($entity_fields, "street");
	$city = get_field_data($entity_fields, "city");
	$state = get_field_data($entity_fields, "state");
	$postal_code = get_field_data($entity_fields, "postal_code");
	$country = get_field_data($entity_fields, "country");
	// $bill_pobox = htmlspecialchars($entity_fields["bill_pobox"]);
		$ship_street = get_field_data($entity_fields, "ship_street");
		$ship_city = get_field_data($entity_fields, "ship_city");
		$ship_state = get_field_data($entity_fields, "ship_state");
		$ship_postal_code = get_field_data($entity_fields, "ship_postal_code");
		$ship_country = get_field_data($entity_fields, "ship_country");
		// $ship_pobox = htmlspecialchars($entity_fields["ship_pobox"]);

	$country = $country ?: $state;

# FE
if ($type == "FE") {
    if ($vat_type) {
        $vat_type = explode(" -", $vat_type)[0];
        $vat_type = "<VatType>".$vat_type."</VatType>\n";
    }

    if ($fepaymentcode == "MP05") {
        $paymentdescript = "<PaymentMethodDescription>".$iban."</PaymentMethodDescription>\n";
    }
}

# Products
	$products = $fattura["products"];

	$ret =	"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n".
		"<Fattura24>\n".
		"	<Document>\n".
		"		<b><DocumentType>$type</DocumentType></b>\n".
		"		<CustomerName><![CDATA[".($surname ? ($name." ".$surname) : $name)."]]></CustomerName>\n".
		"		<CustomerAddress><![CDATA[$street]]></CustomerAddress>\n".
		"		<CustomerPostcode>$postal_code</CustomerPostcode>\n".
		"		<CustomerCity>$city</CustomerCity>\n".
		"		<CustomerProvince>$provincia_fatturazione</CustomerProvince>\n".
		"		<CustomerCountry>$country</CustomerCountry>\n".
		"		<CustomerFiscalCode>".$fiscal_code."</CustomerFiscalCode>\n".
		"		<CustomerVatCode>$vat_number</CustomerVatCode>\n".
		"		<CustomerCellPhone>$phone</CustomerCellPhone>\n".
		"		<CustomerEmail>$email</CustomerEmail>\n";

    if ($type == "FE") {
        $ret = $ret.
            "		<FeCustomerPec>".$fe_customer_pec."</FeCustomerPec>\n".
            "		<FeDestinationCode>".$fe_destination_code."</FeDestinationCode>\n".
            "		<FePaymentCode>".$fepaymentcode."</FePaymentCode>\n".
            $paymentdescript.
            $vat_type;
    } else {
        $ret = $ret.
            "		<DeliveryName>$name</DeliveryName>\n".
            "		<DeliveryAddress>".($ship_street ?: $street)."</DeliveryAddress>\n".
            "		<DeliveryPostcode>".($ship_postal_code ?: $postal_code)."</DeliveryPostcode>\n".
            "		<DeliveryCity>".($ship_city ?: $city)."</DeliveryCity>\n".
            "		<DeliveryProvince>$provincia_consegna</DeliveryProvince>\n".
            "		<DeliveryCountry>".($ship_country ?: $country)."</DeliveryCountry>\n".
            "		<PaymentMethodDescription>".$iban."</PaymentMethodDescription>\n".
            "		<UpdateStorage>1</UpdateStorage>\n".
    		"		<F24OrderId></F24OrderId>\n".
    		"		<IdTemplate></IdTemplate>\n".
    		"		<Payments>\n".
    		"			<Payment>\n".
    		"				<Date>".$data_pagamento."</Date>\n".
    		"				<Amount>".number_format($totale,2,".","")."</Amount>\n".
    		"				<Paid>false</Paid>\n".
    		"			</Payment>\n".
    		"		</Payments>\n";
    }

	$ret = $ret.
		"		<Object><![CDATA[$subject]]></Object>\n".
		"		<TotalWithoutTax>".number_format($sub_totale,2,".","")."</TotalWithoutTax>\n".
		"		<PaymentMethodName>".$metodopagamento."</PaymentMethodName>\n".
		"		<VatAmount>".number_format($tasse,2,".","")."</VatAmount>\n".
		"		<Total>".number_format($totale,2,".","")."</Total>\n".
		"		<FootNotes>$termini</FootNotes>\n".
		"		<SendEmail>$send_email</SendEmail>\n".
		"		<Rows>\n";

	$count = 1;
	foreach($products as $ps) {
		$productid = $ps["hdnProductcode$count"];
		$quantity = $ps["qty$count"];
		$price = $ps["listPrice$count"];
		$comment = $ps["comment$count"];
        // $iva = number_format($ps["taxes"][0]["percentage"],0,"","");
        // $iva = number_format($ps["taxTotal$count"][0]["percentage"],0,"","");
		// $iva = number_format($ps["taxes"][0]["percentage"],0,"","");

        $iva = number_format($iva_amount,0,"","");


        $fevat = "";

        if ($type == "FE") {
            $adb = PearDatabase::getInstance();
    		$sql = "select fevatnature from vtiger_products where product_no = \"".$productid."\"";
            $res = $adb->pquery($sql, array());
            $fevatnature = "";
            for ($i = 0; $i < $adb->num_rows($res); $i++) {
                $fevatnature = $adb->query_result($res, $i, "fevatnature");
                $fevatnature = explode(" -", $fevatnature)[0];
            }

            if ($iva == "0") {
                $fevat = "<FeVatNature>".$fevatnature."</FeVatNature>\n";
            }
        }

		if ($productid == null || $productid == "")
			continue;

		if ($comment == "")
			$comment = "NESSUN COMMENTO";

		$ret =	$ret.
			"			<Row>\n".
			"				<Code>$productid</Code>\n".
			"				<Description><![CDATA[$comment]]></Description>\n".
			"				<Qty>$quantity</Qty>\n".
			"				<Um></Um>\n".
			"				<Price>".number_format($price, 2, ".", "")."</Price>\n".
			"				<Discounts></Discounts>\n".
			"				<VatCode>$iva</VatCode>\n".
			"				<VatDescription>IVA ".$iva."%</VatDescription>\n".
            "               ".$fevat."".
			"			</Row>\n";
			$count++;

	}

	$ret=	$ret.
		"		</Rows>\n".
		"	</Document>\n".
		"</Fattura24>";

		return $ret;
}

function getFolders() {

	$fieldvalue= array();

	$adb = PearDatabase::getInstance();
	$sql = "select foldername,folderid from vtiger_attachmentsfolder order by foldername";
        $res = $adb->pquery($sql, array());
        for ($i = 0; $i < $adb->num_rows($res); $i++) {
            $fid = $adb->query_result($res, $i, "folderid");
            $fname = $adb->query_result($res, $i, "foldername");
            $fieldvalue[$fid] =  $fname;
        }
        return $fieldvalue;
}

function save_file($doc, $docsize, $fileName) {
	try {
		$db = PearDatabase::getInstance();
		$currentUserModel = Users_Record_Model::getCurrentUserModel();
		$uploadPath = decideFilePath();

		$attachid = $db->getUniqueId('vtiger_crmentity');
		$binFile = sanitizeUploadFileName($fileName, vglobal('upload_badext'));
		$fileName = ltrim(basename(" ".$binFile));

		if (file_put_contents($uploadPath.$attachid."_".$fileName, $doc) > 0) {
			$description = $fileName;
			$date_var = $db->formatDate(date('YmdHis'), true);
			$usetime = $db->formatDate($date_var, true);

			$db->pquery("INSERT INTO vtiger_crmentity(crmid, smcreatorid, smownerid,
				modifiedby, setype, description, createdtime, modifiedtime, presence, deleted)
				VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
				Array($attachid, $currentUserModel->getId(), $currentUserModel->getId(), $currentUserModel->getId(), "Documents Attachment", $description, $usetime, $usetime, 1, 0));

			$mimetype  = "application/pdf";

			echo "$mimetype";

			$db->pquery("INSERT INTO vtiger_attachments SET attachmentsid=?, name=?, description=?, type=?, path=?",
				Array($attachid, $fileName, $description, $mimetype, $uploadPath));

			$document = CRMEntity::getInstance("Documents");
			$document->column_fields['notes_title'] = "$fileName";
			$document->column_fields['filename'] = $fileName;
			$document->column_fields['notecontent'] = "DA CLI";
			$document->column_fields['filesize'] = $docsize; //filesize($fileName);
			$document->column_fields['filetype'] = "application/pdf";
			$document->column_fields['fileversion'] = '';
			$document->column_fields['filestatus'] = 1;
			$document->column_fields['filelocationtype'] = 'I';
			$document->column_fields['folderid'] = 1; // Default Folder
			$document->column_fields['assigned_user_id'] = 1;
			$document->column_fields['filestatus'] = 1;
			$document->save('Documents');

			$db->pquery("INSERT INTO vtiger_seattachmentsrel(crmid, attachmentsid) VALUES(?,?)",
				Array($document->id, $attachid));
			return $document;

		}
		return null;
	} catch (Exception $e) {
		echo $e->getMessage();
	}
}
